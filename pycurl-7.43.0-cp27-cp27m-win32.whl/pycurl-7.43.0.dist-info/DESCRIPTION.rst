This module provides Python bindings for the cURL library.


